INSERT INTO article (title, content,created_at,updated_at) VALUES ('title1', 'content1',now(),now())
INSERT INTO article (title, content,created_at,updated_at) VALUES ('title2', 'content2',now(),now())
INSERT INTO article (title, content,created_at,updated_at) VALUES ('title3', 'content3',now(),now())
